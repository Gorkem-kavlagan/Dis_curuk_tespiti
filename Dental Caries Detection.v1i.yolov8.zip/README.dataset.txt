# Dental Caries Detection > 2025-12-17 2:03am
https://universe.roboflow.com/disproje/dental-caries-detection-4yqna

Provided by a Roboflow user
License: CC BY 4.0

